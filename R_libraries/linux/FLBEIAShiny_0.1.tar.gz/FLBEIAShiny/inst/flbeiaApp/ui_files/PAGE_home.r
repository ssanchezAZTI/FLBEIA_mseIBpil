
fluidPage (
  br(),
  br(),
  br(),
  HTML('<center><img src="FLBEIA.png"></center>'))

