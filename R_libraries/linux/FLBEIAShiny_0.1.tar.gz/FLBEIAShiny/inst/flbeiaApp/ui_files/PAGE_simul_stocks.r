

tabsetPanel(type = "tabs",
            tabPanel( 
              title = "Time series",
                sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeS", label=h4("Years"), min(bio$year), max(bio$year), value=range(bio$year),step = 1),
                  selectizeInput("stockS", label=h4("Stock"), levels(as.factor(bio$stock)), selected=unique(bio$stock),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("indicatorS", label=h4("Indicators"), levels(as.factor(bio$indicator)),selected=unique(bio$indicator)[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioS", label=h4("Scenarios"), levels(as.factor(bio$scenario)), selected=unique(bio$scenario)[1], multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr(),
                  checkboxInput("fitCIS", h5("Show Confident interval"), FALSE),
                  checkboxInput("fitS", h5("Show same scale"), FALSE)
                ),
                mainPanel(
                  plotOutput("plotS")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
            )),
            tabPanel(
              title = "Kobe plot",
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeK", label=h4("Years"), min(bio$year), max(bio$year), value=range(bio$year),step = 1),
                  selectizeInput("stockK", label=h4("Stock"), levels(reference_points$stock), selected=unique(reference_points$stock),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioK", label=h4("Scenarios"), levels(as.factor(bio$scenario)), selected=unique(reference_points$scenario), multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  #selectInput("brpK", label=h4("Biological Refence Point"), choices = c("Blim", "Bpa"), selected="Blim"), 
                  hr()
                ),
                mainPanel(
                  plotOutput("plotK")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
              
            )),
            tabPanel(
              title = "Biological risk", 
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeR", label=h4("Years"), min(as.numeric(risk$year)), max(as.numeric(risk$year)), value=range(as.numeric(risk$year)),step = 1),
                  selectizeInput("stockR", label=h4("Stock"), choices= unique((reference_points$stock)), selected=unique((reference_points$stock))[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioR", label=h4("Scenarios"), levels(as.factor(risk$scenario)), selected= unique((risk$scenario))[1], multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("brpR", label=h4("Biological reference point"), choices=c("pBlim", "pBpa"),selected="pBlim", multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr()
                ),
                mainPanel(
                  plotOutput("plotR")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
            ))
)#end of tabsetPanel
