tabsetPanel(type = "tabs",
  tabPanel("Background"),
  tabPanel("FLBEIA"),
  tabPanel("Partners"),
  tabPanel("Funding")
)
