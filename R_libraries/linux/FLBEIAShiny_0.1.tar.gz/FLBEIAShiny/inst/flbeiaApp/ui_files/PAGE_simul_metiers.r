

tabsetPanel(type = "tabs",
            tabPanel(
              title = "Time series",
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeM", label=h4("Years"), min(as.numeric(mt$year)), max(as.numeric(mt$year)), value=range(as.numeric(mt$year)),step = 1),
                  selectizeInput("fleetM", label=h4("Fleet"), levels(as.factor(mt$fleet)), selected=unique(mt$fleet)[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("metierM", label=h4("Metier"), levels(as.factor(mt$metier)), selected=unique(mt$metier),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioM", label=h4("Scenarios"), levels(as.factor(mt$scenario)), selected=unique(mt$scenario)[1], multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("indicatorM", label=h4("Indicators"), levels(as.factor(mt$indicator)),selected="effort",multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr(),
                  checkboxInput("fitCIM", h5("Show Confident interval"), FALSE),
                  checkboxInput("fitM", h5("Show same scale"), FALSE)
                  
                ),
                mainPanel(
                  plotOutput("plotMM")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
              ))
            # tabPanel(
            #   title = "Net present value",#aldatu behar da dataframe
            #   sidebarLayout(
            #     sidebarPanel(
            #       selectizeInput("metierN", label=h4("Metier"), levels(as.factor(npv$fleet)), selected="DFN_SP",multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
            #       selectizeInput("scenarioN", label=h4("Scenario"), levels(as.factor(npv$scenario)), selected="1",multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
            #       hr()
            #     ),
            #     mainPanel(
            #       plotOutput("plotMN")
            #       # bsTooltip("plotS", "Click to download"),
            #       # bsModal("modal1", "Download plot", "plotS",
            #       #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
            #       #     downloadButton("downloadplotS", "OK"))
            #     )
            #   )),
            # tabPanel(
            #   title = "Economic risk", #change dataframe
            #   sidebarLayout(
            #     sidebarPanel(
            #       selectizeInput("fleetN", label=h4("Fleet"), levels(as.factor(npv$fleet)), selected="DFN_SP",multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
            #       selectizeInput("indicatorE", label=h4("Economic refernce points"), levels(as.factor(flt$indicator)),selected="capacity",multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
            #       hr()
            #     ),
            #     mainPanel(
            #       plotOutput("plotME")
            #       # bsTooltip("plotS", "Click to download"),
            #       # bsModal("modal1", "Download plot", "plotS",
            #       #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
            #       #     downloadButton("downloadplotS", "OK"))
            #     )
            #   )# falta dataframe
            # )
)