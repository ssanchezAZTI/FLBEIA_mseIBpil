flbeiaApp <- function(flbeiaObjs = NULL, RefPts = NULL, bioSumQ = NULL, fltSumQ = NULL, 
                      fltStkSumQ = NULL, mtSumQ = NULL, mtStkSumQ = NULL,
                      advSumQ = NULL, riskSum = NULL, years = dimnames(flbeiaObjs[[1]][[1]][[1]]@n)[[2]],npvQ = NULL, npv = FALSE, npv.y0 = NULL, npv.yrs = NULL) {
  
  require(FLBEIA)
  require(kobe)
  require(ggplot2)
  require(schoolmath)
  
  if(missing(RefPts)){
    stknms <- unique(bio$stock)
    scnms <- unique(bio$scenario)
    reference_points <- data.frame(stock = rep(stknms, each = 6*length(scnms)),
                                   scenario = rep(scnms, each = 6*length(stknms)),
                                   indicator = rep(c('Bmsy','Fmsy', 'Bpa', 'Blim', 'Fpa', 'Flim'), length(stknms)*length(scnms)),
                                   value = NA)
  }
  else{
    reference_points <- RefPts
  }

  if(!is.null(flbeiaObjs)){
    if(is.null(names(flbeiaObjs))){
        scenarios <- 1:length(flbeiaObjs)
    }else{
        scenarios <- names(flbeiaObjs)
    }
    bio   <- NULL
    flt   <- NULL 
    fltStk <- NULL 
    mt     <- NULL 
    mtStk  <- NULL
    adv    <- NULL 
    risk    <- NULL
    npv2 <- NULL
  
    for(sc in names(flbeiaObjs)){
      print(sc)
      flbeiaObj <- flbeiaObjs[[sc]]
      bio    <- rbind(bio,bioSumQ(bioSum(flbeiaObj, scenario = sc, years = years))) 
      flt    <- rbind(flt,fltSumQ(fltSum(flbeiaObj, scenario = sc, years = years))) 
      fltStk <- rbind(fltStk,fltStkSumQ(fltStkSum(flbeiaObj, scenario = sc, years = years))) 
      mt     <- rbind(mt,mtSumQ(mtSum(flbeiaObj, scenario = sc, years = years))) 
      mtStk  <- rbind(mtStk,mtStkSumQ(mtStkSum(flbeiaObj, scenario = sc, years = years))) 
      adv    <- rbind(adv,advSumQ(advSum(flbeiaObj, scenario = sc, years = years))) 
      
      Bpa <- subset(reference_points, indicator=='Bpa' & scenario == sc)[,'value']
      names(Bpa) <- subset(reference_points, indicator=='Bpa' & scenario == sc)[,'stock']
      Blim <- subset(reference_points, indicator=='Blim' & scenario == sc)[,'value']
      names(Blim) <- subset(reference_points, indicator=='Blim' & scenario == sc)[,'stock']
      risk   <- rbind(risk,riskSum(flbeiaObj, scenario = sc, Bpa = Bpa, Blim = Blim, Prflim = 0, years = years)) 
      if(npv == TRUE) npv2    <- rbind(npv2,npvQ(npv(flbeiaObj, scenario = sc, y0 = npv.y0, years = npv.yrs ))) 
    }}
  
  t0 <- subset(bio, indicator == 'f')
  t1 <- subset(bio, indicator == 'ssb')
  
  data <- cbind(t0[,c(1,3:4,6)], t1[,6])
  names(data) <- c('unit', 'year', 'scenario', 'q50.f', 'q50.ssb')
  data <- cbind(data, Bmsy = NA,Fmsy = NA)
  
  for(st in unique(data$unit)){
    for(sc in unique(data$scenario)){
      
      bmsy <- subset(reference_points, stock == st & scenario == sc & indicator == 'Bmsy')
      fmsy <- subset(reference_points, stock == st & scenario == sc & indicator == 'Fmsy')
      
      data[data$unit == st & data$scenario == sc, 'Bmsy'] <- bmsy$value
      data[data$unit == st & data$scenario == sc, 'Fmsy'] <- fmsy$value
    }}
  data$stock <- data$q50.ssb/data$Bmsy
  data$harvest <- data$q50.f/data$Fmsy
  
   assign("bio",    bio,envir = globalenv())
   assign("flt",    flt,envir = globalenv())
   assign("fltStk", fltStk,envir = globalenv())
   assign("mt",     mt,envir = globalenv())
   assign("mtStk",  mtStk,envir = globalenv())
   assign("adv",    adv,envir = globalenv())
   assign("risk",   risk,envir = globalenv())
   assign("npv2",   npv2,envir = globalenv())
   assign("npv",   npv,envir = globalenv())
   assign("data",   data,envir = globalenv())
   assign("reference_points",   reference_points,envir = globalenv())
   
 # load('FLBEIAApp.Rdata')
  shiny::runApp(system.file('flbeiaApp', package='FLBEIAShiny')) 

  }
