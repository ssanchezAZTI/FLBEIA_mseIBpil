

tabsetPanel(type = "tabs",
            tabPanel( 
              title = "Time series",
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeA", label=h4("Years"), min(as.numeric(adv$year)), max(as.numeric(adv$year)), value=range(as.numeric(adv$year)),step = 1),
                  selectizeInput("stockA", label=h4("Stock"), levels(as.factor(adv$stock)), selected=unique(adv$stock),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("indicatorA", label=h4("Indicators"), levels(as.factor(adv$indicator)),selected="tac",multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioA", label=h4("Scenarios"), levels(as.factor(adv$scenario)), selected=unique(adv$scenario)[1], multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr(),
                  checkboxInput("fitCIA", h5("Show Confident interval"), FALSE),
                  checkboxInput("fitA", h5("Show same scale"), FALSE)
                  
                ),
                mainPanel(
                  plotOutput("plotA")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",                  selectizeInput("scenarioA", label=h4("Scenarios"), levels(as.factor(adv$scenario)), selected="1", multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),

                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
              ))
)# end of the tabsetPanel