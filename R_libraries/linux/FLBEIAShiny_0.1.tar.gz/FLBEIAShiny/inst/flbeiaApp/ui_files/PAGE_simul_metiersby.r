
tabsetPanel(type = "tabs",
            tabPanel(
              title = "Time series",
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeMby", label=h4("Years"), min(as.numeric(mtStk$year)), max(as.numeric(mtStk$year)), value=range(as.numeric(mtStk$year)),step = 1),
                 # uiOutput("metierMby"),
                 selectizeInput("fleetMby", label=h4("Fleet"), levels(as.factor(mtStk$fleet)), selected=unique(mtStk$fleet)[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("metierMby", label=h4("Metier"), levels(as.factor(mtStk$metier)), selected=unique(mtStk$metier),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                 selectizeInput("stockMby", label=h4("Stock"), levels(as.factor(mtStk$stock)), selected=unique(mtStk$stock),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("indicatorMby", label=h4("Indicator"), levels(as.factor(mtStk$indicator)), selected="catch", multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioMby", label=h4("Scenario"), levels(as.factor(mtStk$scenario)), selected=unique(mtStk$scenario)[1], multiple=F, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr()
                ),
                mainPanel(
                  plotOutput("plotMby")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
              ))
)# end of the tabsetPanel