
tabsetPanel(type = "tabs",
            tabPanel(
              title = "Time series",
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeF", label=h4("Years"), min(as.numeric(flt$year)), max(as.numeric(flt$year)), value=range(as.numeric(flt$year)),step = 1),
                  selectizeInput("fleetF", label=h4("Fleet"), levels(as.factor(flt$fleet)), selected= unique((flt$fleet)),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioF", label=h4("Scenarios"), levels(as.factor(flt$scenario)), selected=unique((flt$scenario))[1], multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("indicatorF", label=h4("Indicators"), levels(as.factor(flt$indicator)),selected="effort",multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr(),
                  checkboxInput("fitCIF", h5("Show Confident interval"), FALSE),
                  checkboxInput("fitF", h5("Show same scale"), FALSE)
                  
              ),
            mainPanel(
              plotOutput("plotFF")
              # bsTooltip("plotS", "Click to download"),
              # bsModal("modal1", "Download plot", "plotS",
              #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
              #     downloadButton("downloadplotS", "OK"))
            )
            )),
            tabPanel(
              title = "Net present value",
              sidebarLayout(
                sidebarPanel(
                  selectizeInput("fleetN", label=h4("Fleet"), levels(as.factor(npv2$fleet)), selected=unique(npv2$fleet),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioN", label=h4("Scenario"), levels(as.factor(npv2$scenario)), selected=unique(npv2$scenario)[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr()
                ),
                mainPanel(
                  plotOutput("plotFN")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
              )),
            tabPanel(
              title = "Economic risk", #change dataframe
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeE", label=h4("Years"), min(as.numeric(risk$year)), max(as.numeric(risk$year)), value=range(as.numeric(risk$year)),step = 1),
                  selectizeInput("fleetE", label=h4("Fleet"), levels(as.factor(risk[risk$indicator=="pPrflim",]$unit)), selected=unique(flt$fleet)[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioE", label=h4("Scenario"), levels(as.factor(flt$scenario)),selected=unique(npv2$scenario)[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr()
                ),
                mainPanel(
                  plotOutput("plotFE")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
              )# falta dataframe
            )
)
