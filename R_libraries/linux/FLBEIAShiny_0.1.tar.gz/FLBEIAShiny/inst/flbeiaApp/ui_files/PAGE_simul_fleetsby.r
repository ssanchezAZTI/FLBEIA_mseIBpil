


tabsetPanel(type = "tabs",
            tabPanel(
              title = "Time series",
              sidebarLayout(
                sidebarPanel(
                  sliderInput("rangeFby", label=h4("Years"), min(as.numeric(fltStk$year)), max(as.numeric(fltStk$year)), value=range(as.numeric(fltStk$year)),step = 1),
                  selectizeInput("stockFby", label=h4("Stock"), levels(as.factor(fltStk$stock)), selected=unique(fltStk$stock),multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("fleetFby", label=h4("Fleet"), levels(as.factor(fltStk$fleet)), selected=unique(fltStk$fleet)[1],multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("indicatorFby", label=h4("Indicator"), levels(as.factor(fltStk$indicator)), selected="landings", multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
                  selectizeInput("scenarioFby", label=h4("Scenarios"), levels(as.factor(fltStk$scenario)), selected=unique(fltStk$scenario)[1], multiple=F, options=list(plugins=list("remove_button", "drag_drop"))),
                  hr()
                ),
                mainPanel(
                  plotOutput("plotFby")
                  # bsTooltip("plotS", "Click to download"),
                  # bsModal("modal1", "Download plot", "plotS",
                  #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
                  #     downloadButton("downloadplotS", "OK"))
                )
              ))
)# end of the tabsetPanel