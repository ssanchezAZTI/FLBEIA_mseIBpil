
# load("./bio.RData")
# load("./flt.RData")
# load("./mt.RData")
# load("./mtStk.RData")
# load("./fltStk.RData")
# load("./adv.RData")
# load("./risk.RData")
# load("./npv2.RData")
# load("./RefPts.RData")
# load("./data.RData")
# load("./reference_points.RData")


server <- function(input, output){

  # PAGE_simulation STOCK 
  
  # PAGE_simulation STOCK_Times series 
  
  observe ({
    dataS<-reactive({
    req(input$stockS)
    bio[bio$year>=input$rangeS[1] & bio$year<=input$rangeS[2] 
        & bio$stock%in%input$stockS
        & bio$indicator%in%input$indicatorS
        & bio$scenario%in%input$scenarioS,]
  })
  
  ggplotS <-ggplot(dataS(), aes(x=year, y=q50, color=scenario))+
            geom_line(lwd=1)+
            facet_grid(indicator~stock, scales="free")+
            ylab("")+xlab("Year")+
            theme(strip.text=element_text(size=16),
                  legend.title=element_text(size=14),
                  axis.title= element_text(size =14))
  
  ggplotSS <-ggplot(dataS(), aes(x=year, y=q50, color=scenario))+
            geom_line(lwd=1)+
            facet_wrap(indicator~stock, scales="free",ncol=length(input$stockS))+
            ylab("")+ xlab("Year")+
            theme(strip.text=element_text(size=16),
                  legend.title=element_text(size=14),
                  axis.title=element_text(size=14))
  
  output$plotS<-renderPlot({
      print(ggplotS)
      })
  
  if (input$fitCIS == TRUE & input$fitS == FALSE){ # Only ribbon 
    output$plotS <- renderPlot({
      print(ggplotS + 
              geom_ribbon(aes(x=year, ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
              geom_line(aes(color=scenario), lwd = 1))
    })
  }
  
   if (input$fitCIS == TRUE & input$fitS==TRUE){ #ribbon and yscale depends on indicator
     output$plotS <- renderPlot({
       print(ggplotSS + 
               geom_ribbon(aes(x=year, ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
               geom_line(aes(color=scenario), lwd = 1))
     })
   }
  
  if (input$fitCIS == FALSE & input$fitS==TRUE){#only y_scale depends on indicator
    output$plotS <- renderPlot({
      print(ggplotSS)
    })
  }
  
 
  })# end of the observe stock 
  
  
  # PAGE_simulation STOCK_kobe plot 
  
  dataK<-reactive({
    req(input$stockK)
    data[data$year>=input$rangeK[1] & data$year<=input$rangeK[2] 
        & data$unit%in%input$stockK
        & data$scenario%in%input$scenarioK,]
  })
  
  output$plotK <- renderPlot({
   print(names(dataK()))
    kobePhase(dataK())+
     geom_point(aes(stock,harvest, group=unit, col=scenario))+
     geom_text(data=dataK(),aes(stock,harvest, col=scenario, group=unit, label=year))+
     geom_path(aes(stock, harvest, group=unit, col=scenario), data=dataK())+
     facet_wrap(~unit)+
       theme(text=element_text(size=16),
             title=element_text(size=16),
             strip.text=element_text(size=16))
  })
  
  # PAGE_simulation STOCK_Biological risk
   
  dataR<-reactive({
    req(input$stockR)
    risk[risk$year>=input$rangeR[1] & risk$year<=input$rangeR[2] 
         & risk$unit%in%input$stockR
         & risk$scenario%in%input$scenarioR
         & risk$indicator%in%input$brpR,]
  })
  
  output$plotR<-renderPlot({
    ggplot(dataR(), aes(x=year, y=value, group=scenario, color=scenario))+
    geom_line()+
    facet_grid(unit~indicator)+
    theme_bw()+
    theme(text=element_text(size=16),
          #title=element_text(size=16,face="bold"),
          title=element_text(size=16),
          strip.text=element_text(size=16),
          axis.text.x = element_text(angle = 90, hjust = 1))+
    xlab("Year")+ ylab("Probability")
  })
  
  # PAGE_simulation FLEET
  
  # PAGE_simulation FLEET_TIMES SERIES
  
  observe ({
    dataF<-reactive({
      req(input$fleetF)
      flt[flt$year>=input$rangeF[1] & flt$year<=input$rangeF[2] 
          & flt$fleet%in%input$fleetF
          & flt$scenario%in%input$scenarioF
          & flt$indicator%in%input$indicatorF,]
    })
    
    ggplotF <-ggplot(dataF(), aes(x=as.numeric(year), y=q50, color=scenario))+
      geom_line(aes(color=scenario),lwd=1)+
      facet_grid(indicator~fleet, scales="free")+
      ylab("")+
      xlab("Year")+
      theme(strip.text=element_text(size=16),
            legend.title=element_text(size=14),
            axis.title=element_text(size=14))
    
    ggplotFF <-ggplot(dataF(), aes(x=as.numeric(year), y=q50, color=scenario))+
      geom_line(aes(color=scenario),lwd=1)+
      facet_wrap(indicator~fleet, scales="free",ncol=length(input$fleetF))+
      ylab("")+
      xlab("Year")+
      theme(strip.text=element_text(size=16),
            legend.title=element_text(size=14),
            axis.title=element_text(size=14))
    
    output$plotFF<-renderPlot({
      print(ggplotF)
    })
    
    if (input$fitCIF == TRUE & input$fitF == FALSE){ # Only ribbon 
      output$plotFF <- renderPlot({
        print(ggplotF + 
                geom_ribbon(aes(x=as.numeric(year), ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
                geom_line(aes(color=scenario), lwd = 1))
      })
    }
    
    if (input$fitCIF == TRUE & input$fitF==TRUE){ #ribbon and yscale depends on indicator
      output$plotFF <- renderPlot({
        print(ggplotFF + 
                geom_ribbon(aes(x=as.numeric(year), ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
                geom_line(aes(color=scenario), lwd = 1))
      })
    }
    
    if (input$fitCIF == FALSE & input$fitF==TRUE){#only y_scale depends on indicator
      output$plotFF <- renderPlot({
        print(ggplotFF)
      })
    }
})#end of the observer
  
  
  # PAGE_simulation FLEET_NPV
  
  dataN<-reactive({
    req(input$fleetN)
    npv2[npv2$fleet%in%input$fleetN
        & npv2$scenario%in%input$scenarioN,]})
  
  output$plotFN<-renderPlot({
  
  ggplot(dataN(), aes(x=fleet, y=q50, group=scenario))+
    geom_point(aes(color=fleet),cex=2)+
    geom_errorbar(aes(ymin=q05, ymax=q95, color=fleet), lwd=1)+
    theme_bw()+
    facet_wrap(~scenario)+
    theme(text=element_text(size=16),
          title=element_text(size=16),
          strip.text=element_text(size=16),
          axis.text.x=element_blank(),
          axis.ticks.x=element_blank())+
    ylab("NPV")
    
    })
  
  
  # PAGE_simulation FLEET_Risk
  
  dataE<-reactive({
    req(input$fleetE)
    risk[risk$unit%in%input$fleetE
        & risk$scenario%in%input$scenarioE
        & risk$indicator=="pPrflim",]})
  
  output$plotFE<-renderPlot({
    
   ggplot(dataE(), aes(x=as.numeric(year), y=value, color=scenario))+
      geom_line(aes(color=scenario),lwd=1)+
      facet_wrap(~unit, scales="free")+
      ylab("")+ xlab("Year")+
      theme(strip.text=element_text(size=16),
            legend.title=element_text(size=14),
            axis.title= element_text(size =14))
      

    
  })
  
  
  
  # PAGE_simulation METIER_Times series 
  
  observe ({
    dataM<-reactive({
      req(input$metierM)
      mt[mt$year>=input$rangeM[1] & mt$year<=input$rangeM[2] 
         & mt$fleet%in%input$fleetM
          & mt$metier%in%input$metierM
          & mt$scenario%in%input$scenarioM
          & mt$indicator%in%input$indicatorM,]
    })
    
    ggplotM <-ggplot(dataM(), aes(x=as.numeric(year), y=q50, color=scenario))+
      geom_line(aes(color=scenario),lwd=1)+
      facet_grid(indicator~metier, scales="free")+
      ylab("")+
      xlab("Year")+
      theme(strip.text=element_text(size=16),
            legend.title=element_text(size=14),
            axis.title=element_text(size=14))
    
    ggplotMM<-ggplot(dataM(), aes(x=as.numeric(year), y=q50, color=scenario))+
      geom_line(aes(color=scenario),lwd=1)+
      facet_wrap(indicator~metier, scales="free",ncol=length(input$metierM))+
      ylab("")+
      xlab("Year")+
      theme(strip.text=element_text(size=16),
            legend.title=element_text(size=14),
            axis.title=element_text(size=14))
    
    output$plotMM<-renderPlot({
      print(ggplotM)
    })
    
    if (input$fitCIM == TRUE & input$fitM == FALSE){ # Only ribbon 
      output$plotMM <- renderPlot({
        print(ggplotM + 
                geom_ribbon(aes(x=as.numeric(year), ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
                geom_line(aes(color=scenario), lwd = 1))
      })
    }
    
    if (input$fitCIM == TRUE & input$fitM==TRUE){ #ribbon and yscale depends on indicator
      output$plotMM <- renderPlot({
        print(ggplotMM + 
                geom_ribbon(aes(x=as.numeric(year), ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
                geom_line(aes(color=scenario), lwd = 1))
      })
    }
    
    if (input$fitCIM == FALSE & input$fitM==TRUE){#only y_scale depends on indicator
      output$plotMM <- renderPlot({
        print(ggplotMM)
      })
    }
  })#end of the observer
  
  
  # PAGE_simulation FLEET BY_Times series 
  
    
    dataFby<-reactive({
      
        fltStk[fltStk$year>=input$rangeFby[1] & fltStk$year<=input$rangeFby[2] 
           & fltStk$stock%in%input$stockFby
           & fltStk$fleet%in%input$fleetFby
           & fltStk$indicator%in%input$indicatorFby
           & fltStk$scenario==input$scenarioFby,]
    })
      
      
    
    output$plotFby<-renderPlot({
      
     ggplot(dataFby(), aes(x=as.numeric(year), y=q50, color=stock))+
        geom_line(aes(color=stock),lwd=1)+
        facet_grid(indicator~fleet, scales="free")+
        ylab("")+
        xlab("Year")+
        theme(strip.text=element_text(size=16),
              legend.title=element_text(size=14),
              axis.title=element_text(size=14))
      
    })
    
    # PAGE_simulation METIER BY_Times series 
    
    
    dataMby<-reactive({
      
      mtStk[mtStk$year>=input$rangeMby[1] & mtStk$year<=input$rangeMby[2] 
             & mtStk$stock%in%input$stockMby
             & mtStk$metier%in%input$metierMby
            & mtStk$fleet%in%input$fleetMby
             & mtStk$indicator%in%input$indicatorMby
             & mtStk$scenario==input$scenarioMby,]
    })
    
    
#    output$metierMby<-renderUI({
      
#      levelsMby<-levels(as.factor(mtStk[mtStk$stock%in%input$stockMby,]$metier))
      
#      selectizeInput("metier.Mby", label=h4("Metier"), levelsMby,multiple=T, selected="OTB_MPD_>=55_0_0",options=list(plugins=list("remove_button", "drag_drop")))
      
#    })
    
    output$plotMby<-renderPlot({
  
      ggplot(dataMby(), aes(x=as.numeric(year), y=q50, color=stock))+
        geom_line(aes(color=stock),lwd=1)+
        facet_grid(indicator~metier, scales="free")+
        ylab("")+
        xlab("Year")+
        theme(strip.text=element_text(size=16),
              legend.title=element_text(size=14),
              axis.title=element_text(size=14))
      
    })
    
    # PAGE_simulation STOCK_Times series 
    
    observe ({
      dataA<-reactive({
        req(input$stockA)
        adv[adv$year>=input$rangeA[1] & adv$year<=input$rangeA[2] 
            & adv$stock%in%input$stockA
            & adv$indicator%in%input$indicatorA
            & adv$scenario%in%input$scenarioA,]
      })
      
      ggplotA <-ggplot(dataA(), aes(x=as.numeric(year), y=q50, color=scenario))+
        geom_line(lwd=1)+
        facet_grid(indicator~stock, scales="free")+
        ylab("")+ xlab("Year")+
        theme(strip.text=element_text(size=16),
              legend.title=element_text(size=14),
              axis.title=element_text(size=14))
      
      ggplotAA <-ggplot(dataA(), aes(x=as.numeric(year), y=q50,fill=indicator))+
        geom_line(lwd=1)+
        facet_wrap(~scenario, scales="free",ncol=length(input$stockA))+
        ylab("")+ xlab("Year")+
        theme(strip.text=element_text(size=16),
              legend.title=element_text(size=14),
              axis.title=element_text(size=14))
      
      output$plotA<-renderPlot({
        print(ggplotA)
      })
      
      if (input$fitCIA == TRUE & input$fitA == FALSE){ # Only ribbon 
        output$plotA <- renderPlot({
          print(ggplotA + 
                  geom_ribbon(aes(x=as.numeric(year), ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
                  geom_line(aes(color=scenario), lwd = 1))
        })
      }
      
      if (input$fitCIA == TRUE & input$fitA==TRUE){ #ribbon and yscale depends on indicator
        output$plotA <- renderPlot({
          print(ggplotAA + 
                  geom_ribbon(aes(x=as.numeric(year), ymin=q05, ymax=q95,fill = scenario), alpha=0.3) +
                  geom_line(aes(color=scenario), lwd = 1))
        })
      }
      
      if (input$fitCIA == FALSE & input$fitA==TRUE){#only y_scale depends on indicator
        output$plotA <- renderPlot({
          print(ggplotAA)
        })
      }
      
      
    })# end of the observe advice
    
   
    # PAGE_simulation Summary_polar plots 
    
    #reactive: ssb and f
    st1 <- reactive({bio[bio$scenario==input$scenarioP & (bio$indicator=="ssb" | bio$indicator=="f") & bio$year==input$yearP, c("stock","year","indicator","q50")]})
    st2 <- reactive({bio[bio$scenario==input$scenarioP & (bio$indicator=="ssb" | bio$indicator=="f") & (bio$year>=input$rangeP[1] & bio$year<=input$rangeP[2]), c("stock","year","indicator","q50")]})
     
    #reactive: profits and capacity
    fl1 <- reactive({flt[flt$scenario==input$scenarioP & (flt$indicator=="profits" | flt$indicator=="capacity") & flt$year==input$yearP, c("fleet","year","indicator","q50")]})
    fl2 <- reactive({flt[flt$scenario==input$scenarioP & (flt$indicator=="profits" | flt$indicator=="capacity") & (flt$year>=input$rangeP[1] & flt$year<=input$rangeP[2]), c("fleet","year","indicator","q50")]})
    
    output$plotP <- renderPlot({
      
  
      # New data entry
      dat.stpolar <- NULL
      dat.flpolar <- NULL
      
      st3 <- aggregate(q50 ~ stock + indicator, data=st2(), FUN=mean)
      fl3 <- aggregate(q50 ~ fleet + indicator, data=fl2(), FUN=mean)
   
      # cuadrante superior: 2 biological indicators by stock:
      st <- merge(st1(), st3, by=c("indicator","stock"))
      st$ratio <- st$q50.x/st$q50.y
      st.dat <- st
      st.dat$stock <- paste("stock.",st.dat$stock,sep="")
      st.dat$scenario <- input$scenarioP
   
      # cuadrante inferior: 2 economical indicators
      fl <- merge(fl1(), fl3, by=c("indicator","fleet"), all.x=TRUE)
      fl$ratio <- fl$q50.x/fl$q50.y
      fl.dat <- fl
      fl.dat$fleet <- paste("fleet.",fl.dat$fleet,sep="")
      fl.dat$scenario <- input$scenarioP

      # number of stocks and fleets
      nst <- length(unique(st.dat$stock)) # number of stocks
      nfl <- length(unique(fl.dat$fleet))
      
      w <- scm(nst, nfl)
      wst <- w/nst
      wfl <- w/nfl
      
      # Index to plot them
      st.dat$ind <- seq(0, wst*(length(st.dat$ratio)-1), by=wst) + wst/2 
      fl.dat$ind <- wst*length(st.dat$ratio) + seq(0, wfl*(length(fl.dat$ratio)-1), by=wfl) + wfl/2
      
      # save into a general case
      dat.stpolar <- rbind(dat.stpolar, st.dat)
      dat.flpolar <- rbind(dat.flpolar, fl.dat)
      
      # Palettes for fleet and stock (alphabetic order 1:fleet and 2:stock)
      palfl <- RColorBrewer::brewer.pal(nfl , "Pastel1") 
      palst <- RColorBrewer::brewer.pal(nst, "Set1")     
      pal <- c(palfl, palst) # it will sort the categories in alphabetic order

      # The number of 
      
      # Polar plot (ggplot)
      ggplot(dat.stpolar, aes(x=ind, y=ratio))+
        geom_bar(data=dat.stpolar, aes(fill=stock), stat="identity", position="dodge", width=wst)+
        geom_bar(data=dat.flpolar, aes(x=ind, y=ratio, fill=fleet), stat="identity", position="dodge", width=wfl)+
        scale_fill_manual(values = pal)+
        theme_bw()+
        facet_wrap(~scenario)+
        coord_polar(start=-pi/2)+
        theme(axis.ticks.x = element_blank(),
              axis.text.x = element_blank(),
              axis.title.x = element_blank(),
              axis.line.x = element_blank(),
              text=element_text(size=16),
              title=element_text(size=16,face="bold"),
              strip.text=element_text(size=16))+
        geom_hline(aes(yintercept=1))+
        geom_vline(aes(xintercept=0), lwd=1)+
        geom_vline(aes(xintercept=wst*nst), lwd=1)+
        geom_vline(aes(xintercept=wst*nst+wst*nst), lwd=1)+
        geom_vline(aes(xintercept=wst*nst+wst*nst+wfl*nfl), lwd=1)+
        xlim(c(0,4*w))+
        annotate(geom="text",x=w/2, y=7, label=c("ssb"), size=6)+
        annotate(geom="text",x=w*3/2, y=7, label=c("f"), size=6)+
        annotate(geom="text",x=w*5/2, y=7, label=c("profits"), size=6)+
        annotate(geom="text",x=w*7/2, y=7, label=c("capacity"), size=6)+
        labs(fill="")+
        geom_text(aes(x=1, y = min(dat.flpolar$ratio),label = sum(npv2$q50)))
      
      # p+annotate(geom="text", x=5, y=1, label="Scatter plot",
      #            color="red")
      
    })
    
  
} #end of the server