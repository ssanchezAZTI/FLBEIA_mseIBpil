

sidebarLayout( #Heme aldatu behar da dataframe
    sidebarPanel(
      selectInput("yearP", label=h4("Year of proyection"), levels(as.factor(bio$year)), selected=max(bio$year)),
      sliderInput("rangeP", label=h4("Reference years"), min(bio$year), max(bio$year), value=range(bio$year),step = 1),
      selectizeInput("scenarioP", label=h4("Scenarios"), levels(as.factor(bio$scenario)), selected=unique(bio$scenario), multiple=T, options=list(plugins=list("remove_button", "drag_drop"))),
      hr()
    ),
    mainPanel(
      plotOutput("plotP")
      # bsTooltip("plotS", "Click to download"),
      # bsModal("modal1", "Download plot", "plotS",
      #     radioButtons("TypeF", "Format", c("pdf", "png", "tiff"), selected="pdf"),
      #     downloadButton("downloadplotS", "OK"))
    )
  )